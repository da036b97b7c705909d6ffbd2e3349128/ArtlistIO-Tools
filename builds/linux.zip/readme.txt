============================================================
           ARTLIST.IO TOOLS - LINUX EDITION
============================================================

Author: Mu_rpy
Version: artlistio-tools-v1.2

--- QUICK START ---

1. Open terminal in this folder.
2. Run: chmod +x start.sh
3. Run: ./start.sh

--- NOTES ---

* First run installs all dependencies automatically.
* Videos save to: output/videos/
* Audio saves to: output/audio/
============================================================